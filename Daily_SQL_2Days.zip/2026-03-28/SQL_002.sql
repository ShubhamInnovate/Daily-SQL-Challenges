-- SQL Challenge 2: Count number of employees in each department
-- Table: Employees(emp_id, emp_name, department, salary)

SELECT department, COUNT(*) AS total_employees
FROM Employees
GROUP BY department
ORDER BY total_employees DESC;
